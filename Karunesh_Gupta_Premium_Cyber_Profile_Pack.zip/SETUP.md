# Karunesh Gupta — Profile Pack

## Files

- `README.md` → replace the current profile README with this file.
- `assets/karunesh-cyber-header.gif` → animated blue/dark hero.
- `assets/karunesh-cyber-footer.gif` → animated footer.
- `.github/workflows/snake.yml` → optional contribution snake generator.

## Install

Keep the directory structure:

```text
KARUNESH-GUPTA/
├── README.md
├── assets/
│   ├── karunesh-cyber-header.gif
│   └── karunesh-cyber-footer.gif
└── .github/
    └── workflows/
        └── snake.yml
```

Commit and push to the profile repository:

```bash
git add .
git commit -m "Redesign profile README"
git push
```

The README uses relative image paths for the custom GIFs, so the assets stay inside your own repository.
